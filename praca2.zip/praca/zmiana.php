<?php 
	require_once 'connection.php';
	session_start();
	if (isset($_POST['zmna'])) {
		$loginnew=$_POST['zmiana'];
		if ($loginnew=="") {
			echo "<script type='text/javascript'>alert('wpisz dane')</script>";
		}else{
	$login=$_SESSION['id'];
	$spre=mysqli_query($con,"SELECT count(login) FROM uzytkownicy WHERE login='".$loginnew."' ");
  	$r=mysqli_fetch_array($spre);
  	if ($r['count(login)']!=0) {
  	echo "Login jest w użytku wybierz inny";
  }else{
  	$zap="UPDATE uzytkownicy SET login='".$loginnew."' WHERE login='".$login."'";
  	mysqli_query($con,$zap);
  	echo "<script type='text/javascript'>alert('pomyśla zmiana nicku')</script>";
  }	
	}
	}
  if (isset($_POST['wyjscie'])) {
  	header("location:rozmowy.php");
  }
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<title></title>

 </head>
 <body>
 <form method="post" action="zmiana.php">
 	<input type="text" name="zmiana"><br>
 	<input type="submit" name="zmna" value="Zmień"><br>
 	<input type="submit" name="wyjscie" value="Wyjście">
 </form>
 </body>
 </html>